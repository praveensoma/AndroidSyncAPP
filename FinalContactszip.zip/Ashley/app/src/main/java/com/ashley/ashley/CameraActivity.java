package com.ashley.ashley;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Date;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class CameraActivity extends AppCompatActivity {

    private ImageView imageView;
    String currentPhotoPath;
    String videoPhotoPath;
    private Uri fileURI;
    String serverUrl = "https://helix.dev.ashleyfurniture.com/contentmaster/importToHelixContent";

    String photoName = "";
    String videoName = "";
    File photoFile = null;
    File videoFile = null;
    int pressedButtonNumber;
    static final int REQUEST_PIC_CAPTURE = 0;
    static final int REQUEST_VIDEO_CAPTURE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        pressedButtonNumber = getIntent().getExtras().getInt("buttonNumber");
        OpenCamera(pressedButtonNumber);
    }

    private File createFile(int filetype) throws IOException {
        // Create an image file name
        File fileType = null;
        File storageDir;
        String timeStamp = "";
        switch (filetype){
            case 1: timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
                String imageFileName = "JPEG_" + timeStamp + "_";
                photoName = imageFileName;
                storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                fileType = File.createTempFile(
                        imageFileName,  /* prefix */
                        ".jpg",         /* suffix */
                        storageDir      /* directory */
                );

                // Save a file: path for use with ACTION_VIEW intents
                currentPhotoPath = fileType.getAbsolutePath();
                break;
            case 2: timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
                String videoFileName = "MPEG4_" + timeStamp + "_";
                videoName = videoFileName;
                storageDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
                fileType = File.createTempFile(
                        videoFileName,  /* prefix */
                        ".mp4",         /* suffix */
                        storageDir      /* directory */
                );

                // Save a file: path for use with ACTION_VIEW intents
                videoPhotoPath = fileType.getAbsolutePath();
                break;
        }
        return fileType;

    }

    public void OpenCamera(int buttonPressed) {
        switch (buttonPressed) {
            case 1:
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                // Ensure that there's a camera activity to handle the intent
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    // Create the File where the photo should go

                    try {
                        photoFile = createFile(buttonPressed);
                        Log.i("PhotoIntent", "ImageFileCreated");
                    } catch (IOException ex) {
                        Log.i("PhotoIntent", "ImageFileCreationFailed");
                    }
                    // Continue only if the File was successfully created
                    if (photoFile != null) {
                        fileURI = FileProvider.getUriForFile(getApplicationContext(),
                                "com.ashley.ashley.fileprovider",
                                photoFile); //needs work
                        Log.i("PhotoIntent", "URI created");
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, fileURI);
                        startActivityForResult(takePictureIntent, REQUEST_PIC_CAPTURE);
                    }
                }
                break;
            case 2:
                Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
                if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
                    try {
                        videoFile = createFile(buttonPressed);
                        Log.i("VideoIntent", "VideoFileCreated");
                    } catch (IOException ex) {
                        Log.i("VideoIntent", "VideoFileCreationFailed");
                    }
                    // Continue only if the File was successfully created
                    if (videoFile != null) {
                        fileURI = FileProvider.getUriForFile(getApplicationContext(),
                                "com.ashley.ashley.fileprovider",
                                videoFile); //needs work
                        Log.i("VideoIntent", "URI created");
                        takeVideoIntent.putExtra(MediaStore.EXTRA_OUTPUT, fileURI);
                        startActivityForResult(takeVideoIntent, REQUEST_VIDEO_CAPTURE);
                    }

                }
                break;

        }

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if (resultCode != RESULT_CANCELED) {
            JSONObject jsonObj = null;
            File fileCat = null;
            switch(requestCode){
                case REQUEST_PIC_CAPTURE: fileCat = photoFile;
                    break;
                case REQUEST_VIDEO_CAPTURE: fileCat = videoFile;
                    break;
            }

            try {
                jsonObj = new JSONObject("{\"File\": \"" + fileCat + "\"}");
                sendToMainActivity(jsonObj.toString());
                uploadFile(requestCode);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Log.d("TAG", "Camera URI Transmitted");
            finish();

        } else {
            sendToMainActivity("Camera Cancelled by User");

            Log.d("TAG", "Camera Cancelled");
            Toast.makeText(getBaseContext(), "Cancelled", Toast.LENGTH_LONG).show();
            finish();

            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void uploadFile(int fileType) {

        if (fileURI == null) {
            return;
        }

        File fileCat = null;
        switch(fileType){
            case REQUEST_PIC_CAPTURE: fileCat = photoFile;
                break;
            case REQUEST_VIDEO_CAPTURE: fileCat = videoFile;
                break;
        }
        Uri uris = Uri.fromFile(fileCat);
        String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uris.toString());
        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension.toLowerCase());
        String imageName = fileCat.getName();

        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("contentData", imageName,
                        RequestBody.create(fileCat, MediaType.parse(mime)))
                .build();


        OkHttpClient imageUploadClient = new OkHttpClient.Builder()
                .build();
        Request request = new Request.Builder()
                .url(serverUrl)
                .header("contentName", photoName)
                .header("contentDesc", "testDesc")
                .header("contentType", "photo")
                .header("fileName", "photo")
                .header("mime", mime)
                .post(requestBody)
                .build();


        imageUploadClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                String mMessage = e.getMessage().toString();
                //Toast.makeText(ChatScreen.this, "Error uploading file", Toast.LENGTH_LONG).show();
                Log.e("failure Response", mMessage);
                sendToMainActivity("Camera Upload Failed with error: " + e.toString());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String mMessage = response.body().string();
                Log.e("upload response", mMessage);
                sendToMainActivity("Successfully uploaded Camera image with :" + response.toString());
            }
        });
    }

    public void sendToMainActivity(String s) {
        String androidId = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ANDROID_ID);
        JSONObject myMsg = null;
        try {
            myMsg = new JSONObject("{\"deviceId\": \"" + androidId + "\", \"topic\": \"CameraResult\", \"text\": \"text\"}");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            myMsg.put("text", s);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String msg = myMsg.toString();

        Intent in = new Intent("com.ashley.ashley");
        Bundle extras = new Bundle();
        extras.putString("com.ashley.ashley.CAMERA", msg);
        in.putExtras(extras);
        sendBroadcast(in);
    }
}