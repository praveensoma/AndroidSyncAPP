package com.ashley.ashley;

import static java.lang.Math.round;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.ashley.ashley.databinding.ActivityMainBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import com.hanks.passcodeview.PasscodeView;

public class UserMainActivity extends AppCompatActivity {

    private static final int MY_PERMISSIONS_REQUEST_CODE = 123;
    private BroadcastReceiver broadcastReceiver;
    private static final int PERMISSIONS_REQUEST_RECORD_AUDIO = 1;
    //Proglove Integrate 5


    HelixForegroundService myService;
    boolean isBind = false;
//    private Model mainActivityModel;

    /* Used to handle permission request */


    //SENSOR MANAGER

    private static final String TAG = "UserMainActivity";

    final Handler handler = new Handler();
    private boolean audioPermitted=false;
    private static final String FILE_NAME = "myVariables.json";
    private Runnable runnable;
    Button enableButton;
    PasscodeView passcodeView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_mode);
        enableButton = findViewById(R.id.button4);
        passcodeView = findViewById(R.id.passcodeview);
        passcodeView.setVisibility(View.GONE);
        if(Boolean.parseBoolean(getVariable("developerMode"))){
            Intent i = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(i);
        }else {


            Intent serviceIntent = new Intent(this, HelixForegroundService.class);
            serviceIntent.putExtra("inputExtra", "Service Started");
            bindService(serviceIntent, mConnection, Context.BIND_AUTO_CREATE);
            ContextCompat.startForegroundService(UserMainActivity.this, serviceIntent);

            registerReceiver();


            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                checkPermission();
            }
            // Function to check and request permission.

            // Check if user has given permission to record audio, init the model after permission is granted
            int permissionCheck = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.RECORD_AUDIO);
            if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSIONS_REQUEST_RECORD_AUDIO);
            } else {
                audioPermitted = true;

            }
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 0);
            }


        }
    }
    //datafile started
    public void setVariable(String variableName, String variableValue){
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject = new JSONObject(readFromFile());
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            jsonObject.put(variableName, variableValue);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            writeToFile(jsonObject);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public String getVariable(String variableName){
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject = new JSONObject(readFromFile());
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        String variableValue=null;
        try {
            variableValue=jsonObject.get(variableName).toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return variableValue;
    }

    public void writeToFile(JSONObject JsonObject) throws IOException {
        // Convert JsonObject to String Format
        String userString = JsonObject.toString();
// Define the File Path and its Name
        File file = new File(this.getApplicationContext().getFilesDir(),FILE_NAME);
        FileWriter fileWriter = new FileWriter(file);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        bufferedWriter.write(userString);
        bufferedWriter.close();
    }
    public String readFromFile() throws IOException {
        File file = new File(this.getApplicationContext().getFilesDir(),FILE_NAME);
        FileReader fileReader = new FileReader(file);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        StringBuilder stringBuilder = new StringBuilder();
        String line = bufferedReader.readLine();
        while (line != null){
            stringBuilder.append(line).append("\n");
            line = bufferedReader.readLine();
        }
        bufferedReader.close();
// This responce will have Json Format String
        String responce = stringBuilder.toString();
        return responce;
    }

    //datafile ended

    private void registerReceiver() {
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String killMsg = intent.getStringExtra("com.ashley.ashley.COMM");
                if (killMsg != null) {
                    if (killMsg.equals("KILL")) {
                        finishAndRemoveTask();
                        android.os.Process.killProcess(android.os.Process.myPid());
                    }else if(killMsg.equals("RESTART")){
                        handler.postDelayed(runnable, 3000);
                    }
                }


                String closeActivity = intent.getStringExtra("com.ashley.ashley.STOPMAIN");
                if (closeActivity != null) {
                    finishAndRemoveTask();
                }

            }
        };
        registerReceiver(broadcastReceiver, new IntentFilter("com.ashley.ashley"));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (broadcastReceiver != null) {
            unregisterReceiver(broadcastReceiver);
        }
    }


    protected void checkPermission() {
        Activity mActivity = UserMainActivity.this;
        if (ContextCompat.checkSelfPermission(mActivity, Manifest.permission.CAMERA)
                + ContextCompat.checkSelfPermission(
                mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                + ContextCompat.checkSelfPermission(
                mActivity, Manifest.permission.RECORD_AUDIO)
                + ContextCompat.checkSelfPermission(
                mActivity, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            // Do something, when permissions not granted
            if (ActivityCompat.shouldShowRequestPermissionRationale(
                    mActivity, Manifest.permission.CAMERA)
                    || ActivityCompat.shouldShowRequestPermissionRationale(
                    mActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    || ActivityCompat.shouldShowRequestPermissionRationale(
                    mActivity, Manifest.permission.RECORD_AUDIO)
                    || ActivityCompat.shouldShowRequestPermissionRationale(
                    mActivity, Manifest.permission.ACCESS_FINE_LOCATION)) {
                // If we should give explanation of requested permissions

                // Show an alert dialog here with request explanation
                AlertDialog.Builder builder = new AlertDialog.Builder(mActivity);
                builder.setMessage("Camera, Audio, Location and Write External" +
                        " Storage permissions are required to do the task.");
                builder.setTitle("Please grant those permissions");
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        ActivityCompat.requestPermissions(
                                mActivity,
                                new String[]{
                                        Manifest.permission.CAMERA,
                                        Manifest.permission.RECORD_AUDIO,
                                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                        Manifest.permission.ACCESS_FINE_LOCATION
                                },
                                MY_PERMISSIONS_REQUEST_CODE
                        );
                    }
                });
                builder.setNeutralButton("Cancel", null);
                AlertDialog dialog = builder.create();
                dialog.show();
            } else {
                // Directly request for required permissions, without explanation
                ActivityCompat.requestPermissions(
                        mActivity,
                        new String[]{
                                Manifest.permission.CAMERA,
                                Manifest.permission.RECORD_AUDIO,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                                Manifest.permission.ACCESS_FINE_LOCATION
                        },
                        MY_PERMISSIONS_REQUEST_CODE
                );
            }
        } else {
            audioPermitted=true;

            // Do something, when permissions are already granted
            Toast.makeText(UserMainActivity.this, "Permissions already granted", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_CODE: {
                // When request is cancelled, the results array are empty
                if (
                        (grantResults.length > 0) &&
                                (grantResults[0]
                                        + grantResults[1]
                                        + grantResults[2]
                                        + grantResults[3]
                                        == PackageManager.PERMISSION_GRANTED
                                )
                ) {
                    // Permissions are granted
                    audioPermitted=true;

                    Toast.makeText(UserMainActivity.this, "Permissions granted.", Toast.LENGTH_SHORT).show();
                } else {
                    audioPermitted=false;
                    // Permissions are denied
                    Toast.makeText(UserMainActivity.this, "Permissions denied.", Toast.LENGTH_SHORT).show();
                }
                return;
            }
        }
    }

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {

            HelixForegroundService.LocalService localService = (HelixForegroundService.LocalService) service;
            myService = localService.getService();

            isBind = true;
            if(isBind && audioPermitted){
                myService.setAllPermissionsGranted();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBind = false;
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        if(Boolean.parseBoolean(getVariable("developerMode"))){
            Intent i = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(i);
        }else {
            if (!isBind) {
                Intent serviceIntent = new Intent(this, HelixForegroundService.class);
                serviceIntent.putExtra("inputExtra", "Service Started");
                bindService(serviceIntent, mConnection, Context.BIND_AUTO_CREATE);
                isBind = false;
            }
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        if (isBind) {
            unbindService(mConnection);
            isBind = false;
        }
        handler.removeCallbacks(runnable);
    }

    public void enableDeveloperMode(View v) {

        enableButton.setVisibility(View.GONE);
        passcodeView.setVisibility(View.VISIBLE);
        // to set length of password as here
        // we have set the length as 5 digits
        passcodeView.setPasscodeLength(5)
                // to set pincode or passcode
                .setLocalPasscode("54321")

                // to set listener to it to check whether
                // passwords has matched or failed
                .setListener(new PasscodeView.PasscodeViewListener() {
                    @Override
                    public void onFail() {
                        // to show message when Password is incorrect
                        Toast.makeText(UserMainActivity.this, "Password is wrong!", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onSuccess(String number) {
                        // here is used so that when password
                        // is correct user will be
                        // directly navigated to next activity
//                            Intent intent_passcode = new Intent(UserMainActivity.this, passcode_activity.class);
//                            startActivity(intent_passcode);

                        setVariable("developerMode", String.valueOf(true));
                        Intent i = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(i);

                    }
                });
    }

};







