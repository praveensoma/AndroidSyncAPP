package com.ashley.ashley;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

import com.ashley.ashley.databinding.ActivityHelixBinding;

public class HelixActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {

    private ActivityHelixBinding _binding;
    private String _targetUrl = "https://helix.dev.ashleyfurniture.com/#/checkinout";
    private WebView _webView;
    private SwipeRefreshLayout _refreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        _binding = ActivityHelixBinding.inflate(getLayoutInflater());
        setContentView(_binding.getRoot());

        _refreshLayout = (SwipeRefreshLayout) findViewById(R.id.swiperefresh);

        HelixApplication app = (HelixApplication) getApplication();
        _webView = app.getWebView();
        if (!app.isWebViewInitialized()) {
            _webView.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT));
            setupWebViewSettings();
            _webView.loadUrl(_targetUrl);
            app.setWebViewInitialized(true);
        }


        _refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh () {
                _webView.reload();
                _refreshLayout.setRefreshing(false);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        _refreshLayout.addView(_webView);
    }

    @Override
    protected void onStop() {
        super.onStop();
        _refreshLayout.removeAllViews();
    }

    @Override
    public void onRefresh () {
        _webView.reload();
    }

    @Override
    public void onBackPressed(){
        if(_webView.canGoBack()) {
            _webView.goBack();
        }
        else{
            super.onBackPressed();
        }
    }

    private void setupWebViewSettings() {
        _webView.setWebViewClient(new WebViewClient());

        WebSettings settings = _webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAppCacheEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setBuiltInZoomControls(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(false);
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        _webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(_webView, true);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        // Extras tried for Android 9.0, can be removed if want.
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccess(true);
        settings.setBlockNetworkImage(false);
    }
}