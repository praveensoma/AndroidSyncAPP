const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    res.status(200).send("Entering functional APIs...");
})

router.get('/download', (req, res) => {
    const filePath = `${process.cwd()}/src/assets/employee.zip`
    res.status(200).download(filePath)
})

module.exports = router;