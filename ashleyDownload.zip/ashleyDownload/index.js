const express = require('express');
const app = express();
const routes = require('./src/routes/routes')

const port = process.env.PORT || 3000;

app.get('/', (req, res) => {
    res.status(200).send("----Welcome to Ashley Furnitures Data Manager----");
});

app.use('/api', routes);

app.listen(port, (error) => {
    if (!error)
        console.log("Server is Successfully Running, and App is listening on port " + port)
    else
        console.log("Error occurred, server can't start", error);
});