package com.example.empcontacts.utils;

public class SyncronizationException extends RuntimeException {

    public SyncronizationException()
    {

    }

    public SyncronizationException(String message)
    {
      super(message);
    }

    public SyncronizationException(String message,Throwable cause)
    {
        super(message,cause);
    }


}
