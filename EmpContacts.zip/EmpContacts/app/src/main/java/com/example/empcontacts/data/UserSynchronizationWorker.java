package com.example.empcontacts.data;

import android.app.DownloadManager;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.concurrent.futures.CallbackToFutureAdapter;
import androidx.dynamicanimation.animation.SpringAnimation;
import androidx.work.ListenableWorker;
import androidx.work.WorkerParameters;

import com.android.volley.Request;
import com.android.volley.RequestQueue;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import  com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.empcontacts.model.User;
import com.example.empcontacts.utils.SyncronizationException;
import com.example.empcontacts.utils.synchronizationcallback;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.util.concurrent.ListenableFuture;

import org.json.JSONArray;

public class UserSynchronizationWorker extends ListenableWorker {
    private final String url="http://10.0.2.2:3000";
    private final String  endpoint = String.format("%s%s",url,"/users");
    private static final String TAG="synchronization";
    public static  final String NAME = UserSynchronizationWorker.class.getSimpleName();
    private final String errorMessage = "Something went wrong while fetching user data";


    private final Executor executor;
    private final RequestQueue requestQueue;
    private final ObjectMapper objectMapper;

    UserSynchronizationWorker(@NonNull Context appcontext, @NonNull WorkerParameters workerParameters)
    {
        super(appcontext,workerParameters);
        executor = Executors.newSingleThreadExecutor();
        requestQueue = Volley.newRequestQueue(appcontext);
        objectMapper = new ObjectMapper();

    }

    @NonNull
    @Override
    public ListenableFuture<Result> startWork() {

        return CallbackToFutureAdapter.getFuture( completer -> {
            synchronizationcallback callback = new synchronizationcallback()
            {
                @Override
                public void onFailure(SyncronizationException exception) {
                    completer.set(Result.failure());
                }

                @Override
                public void onResponse(JSONArray jsonArray) {
                    List<User> users = read(jsonArray);
                    users.forEach(
                            System.out::println
                    );
                    completer.set(Result.success());
                }

            };
            completer.addCancellationListener(new Runnable() {
                @Override
                public void run() {
                    if(requestQueue!=null)
                    {
                        requestQueue.cancelAll(TAG);
                    }
                }
            },executor);
            getUsers(callback);
            {
                return callback;
            }
        });
        //return null;

    }
    private void getUsers(synchronizationcallback callback)
    {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET,
                endpoint, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                callback.onResponse(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                callback.onFailure(new SyncronizationException(errorMessage,error));
            }
        });
        jsonArrayRequest.setTag(TAG);
        requestQueue.add(jsonArrayRequest);
    }

    private List<User> read(JSONArray jsonArray)
    {
      try {
          return Arrays.asList(objectMapper.readValue(jsonArray.toString(),User[].class));
      }

      catch (IOException e)
      {
          throw  new SyncronizationException(errorMessage,e);
      }
    }
}
