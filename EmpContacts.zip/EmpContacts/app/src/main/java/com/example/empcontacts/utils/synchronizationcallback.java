package com.example.empcontacts.utils;

import org.json.JSONArray;

public interface synchronizationcallback {
     void onFailure(SyncronizationException exception) ;
    void onResponse(JSONArray jsonArray);

}
