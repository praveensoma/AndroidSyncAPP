package com.example.empcontacts.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class User {
    private int id;
    private String name;
    private int age;

    public User(@JsonProperty("id")  int id,
                @JsonProperty("name") String name,
                @JsonProperty("age") int age)
    {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
